#include <iostream>

using namespace std;

int main()
{
  int num1, num2,sum;
  
  cout<<"Enter the integer 1\n";
  cin>>num1;

  cout<<"Enter the integer 2\n";
  cin>>num2;

  sum = num1 + num2;
  
  printf("%d", sum);

return 0;
  
}
